# If you DO have the WhatsApp Desktop app installed
from alright import WhatsApp

msg = "hey I'm done its tuesday"
messenger = WhatsApp()
messenger.send_message1("255xxxxxxxxx", msg)
